from lxml import etree
import requests
import csv
import re
user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.91 Safari/537.36'
headers = {'User-Agent': user_agent}
response = requests.get('http://seputu.com/', headers=headers)
mulu_xpath = "/html/body/div[@class='body']/div[@class='bg']/div[@class='mulu']"
html = etree.HTML(response.text)
rows = []
for mulu in html.xpath(mulu_xpath):
    list = []
    title = mulu.xpath("div[@class='mulu-title']/center/h2/text()")
    if title != []:
        li_lsit = mulu.xpath("div[@class='box']/ul/li")
        for li in li_lsit:

            a_text = li.xpath("a/@title")
            pattern = re.compile(r'\s*\[(.*?)\]\s+(.*)')
            match = pattern.search(a_text[0])

            if match != None:
                a_title = match.group(2)

                a_date = match.group(1)
                a_href = li.xpath("a/@href")
                print(type(a_href[0]))
                content = (title[0],a_title,a_href[0],a_date)
                rows.append(content)

# 写入csv
columns = ['title','a_title','a_href','a_date']
with open('DMBJ.csv','w') as fp:
    f_csv = csv.writer(fp,)
    f_csv.writerow(columns)
    f_csv.writerows(rows)






