# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


from scrapy.loader.processors import MapCompose
class LagouCrawlerItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass



def removsplash(value):

    return value.replace('/','')

class LagouJobItem(scrapy.Item):
    title = scrapy.Field()
    url_object_id = scrapy.Field()
    # url_object_id = scrapy.Field()
    salary_min = scrapy.Field()
    salary_max = scrapy.Field()
    job_city = scrapy.Field(
        input_processor = MapCompose(removsplash)
    )
    work_years = scrapy.Field(
        input_processor=MapCompose(removsplash)
    )
    degree_need = scrapy.Field(
        input_processor=MapCompose(removsplash)
    )#学位
    job_type = scrapy.Field()
    publish_time = scrapy.Field()
    job_advantage = scrapy.Field()#优势
    job_desc = scrapy.Field()
    # job_addr = scrapy.Field()
    # company_name = scrapy.Field()
    # company_url = scrapy.Field()
    tags = scrapy.Field()
    # crawl_time = scrapy.Field()


    
