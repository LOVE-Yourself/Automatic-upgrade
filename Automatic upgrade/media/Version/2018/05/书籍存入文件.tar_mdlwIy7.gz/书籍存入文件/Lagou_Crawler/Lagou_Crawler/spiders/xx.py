
# import hashlib
#
#
# url='12345'
# m = hashlib.md5()
# m.update(url.encode('utf-8'))
# print(m)
# m1 = hashlib.md5()
# url1 = '12345'
# m.update(url1.encode('utf-8'))
# print(m)
# print(m1 == m)
# 'user_trace_token=20171118171559-e468616e-81f9-4ecf-8a41-ad07440716c4; LGUID=20171118171603-198a16d6-cc41-11e7-96d8-525400f775ce; X_HTTP_TOKEN=ff1880fb07f64c5cdc653767d03a72f2; PRE_UTM=; PRE_HOST=; PRE_SITE=; PRE_LAND=https%3A%2F%2Fpassport.lagou.com%2Flogin%2Flogin.html%3Fmsg%3Dvalidation%26uStatus%3D2%26clientIp%3D113.45.72.109; _putrc=CB3A02BD8C181309; JSESSIONID=ABAAABAACBHABBIA712CAFBDB90754494DAC68C8222DFC9; login=true; unick=%E5%BE%90%E5%85%B4%E8%BE%BE; showExpriedIndex=1; showExpriedCompanyHome=1; showExpriedMyPublish=1; hasDeliver=21; gate_login_token=5a8375d6638c23b00340b57c15e67b4383f1c2e66a0e25ea; index_location_city=%E5%8C%97%E4%BA%AC; _gid=GA1.2.319146385.1516953584; _gat=1; Hm_lvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1516953584; Hm_lpvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1516953743; _ga=GA1.2.1549228254.1510996563; LGSID=20180126155944-deaffa01-026e-11e8-9c67-525400f775ce; LGRID=20180126160223-3db6139d-026f-11e8-ab9d-5254005c3644'
#salary = '10k以上'
salary = '10k-20k'
if '-' in salary:

    salary_min = salary.split('-')[0].strip('k')
    salary_max = salary.split('-')[1].strip('k')
    print(salary_min)
    print(salary_max)
else:
    salary_min = salary.split('k')[0]
    salary_max = 100000
    print(salary_min)
