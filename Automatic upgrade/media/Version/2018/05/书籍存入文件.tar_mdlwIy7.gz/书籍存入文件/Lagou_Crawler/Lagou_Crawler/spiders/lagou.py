# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from ..items import LagouJobItem
import hashlib
class LagouSpider(CrawlSpider):
    name = 'lagou'
    allowed_domains = ['www.lagou.com']
    start_urls = ['https://www.lagou.com/']
    job_item = LagouJobItem()
    rules = (
        Rule(LinkExtractor(allow=r'jobs/\d+.html'), callback='parse_job_item', follow=False),
        Rule(LinkExtractor(allow=r'zhaopin/.*'),follow=False),
        # Rule(LinkExtractor(allow=r'gongsi/\d+.html'),follow=True),
        # Rule(LinkExtractor(allow=r'gongsi/j\d+.*'),follow=True)
    )
    def cln_salary(self,response):
        salary = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[1]/text()').extract()[0]
        print('---salary-->',salary)
        if '-' in salary:
            salary_min = salary.split('-')[0].strip('k')
            salary_max = salary.split('-')[1].strip('k')
        else:
            salary_min = salary.split('k')[0]
            salary_max = 10000
        return salary_min,salary_max

    def cln_workyears(self,response):
        work_years = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[3]/text()').extract()[0]
        #work_years




    def parse_job_item(self, response):

        self.job_item['title'] = response.xpath('/html/body/div[2]/div/div[1]/div/@title').extract()[0]
        m = hashlib.md5()
        m.update(response.url.encode('utf-8'))
        self.job_item['url_object_id'] = m.hexdigest()[8:-8]
        print('-->md5',m)
        self.job_item['salary_min'],self.job_item['salary_max'] = self.cln_salary(response)

        self.job_item['job_city'] = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[2]/text()').extract()[0]
        self.job_item['work_years'] = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[3]/text()').extract()[0]
        self.job_item['degree_need'] = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[4]/text()').extract()[0]
        self.job_item['job_type'] = response.xpath('/html/body/div[2]/div/div[1]/dd/p[1]/span[5]/text()').extract()[0]
        tags = response.xpath('/html/body/div[2]/div/div[1]/dd/ul')
        self.job_item['tags'] = tags.xpath('string(.)').extract()[0].replace('\n',' ').strip(' ')

        self.job_item['publish_time'] = response.xpath('/html/body/div[2]/div/div[1]/dd/p[2]//text()').extract()[0]
        self.job_item['job_advantage'] = response.xpath('//*[@id="job_detail"]/dd[1]/p/text()').extract()[0]
        d = response.xpath('//*[@id="job_detail"]/dd[2]/div')
        d1 = d.xpath('string(.)').extract()[0].replace('\n','').strip(' ')
        self.job_item['job_desc'] = d1
        yield self.job_item


