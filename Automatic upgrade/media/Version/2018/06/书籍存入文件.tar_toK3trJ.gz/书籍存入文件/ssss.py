import re

t = '[2012-5-19 3:3:52] 七星鲁王 第一章 血尸'
pattern = re.compile(r'\s*\[(.*?)\]')
match = pattern.search(t)
print(match.group(1))

