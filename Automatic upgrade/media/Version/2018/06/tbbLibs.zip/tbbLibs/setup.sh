#!/usr/bin/env bash
cp ./Lessons.pvr ../
cp ./sendLessonData.py ../
rm -rf ./*.pyc
