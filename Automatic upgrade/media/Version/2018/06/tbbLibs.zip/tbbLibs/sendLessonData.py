#!/usr/bin/env python
# -*- coding:utf-8 -*-
#
__author__ = 'tbb'
import sys
import os
import datetime
import time
import sqlite3
import urllib2
import json
import httplib
import urllib
import traceback
from urllib import unquote
from urllib import quote
from urllib import urlencode

APP_DB_NAME = "APP_DATA_LOCAL.db"
# APP_BASE_URL = "http://192.168.1.151:8080/tuobaba"
APP_BASE_URL = "http://drivesim.tuobaba.cn:5666/tuobaba"
# APP_BASE_URL = "http://192.168.1.176:8080/tuobaba"
'''
reload(sys)
sys.setdefaultencoding('utf8')
'''


class DB_APP:
    def getNotSendOrderList(self):
        todayDate = time.strftime('%Y%m%d', time.localtime(time.time()))
        nowTime = time.strftime('%H:%M', time.localtime(time.time()))
        # nowTime = ""+str(time.time()).split('.')[0]
        try:
            conn = sqlite3.connect(APP_DB_NAME)
            cur = conn.cursor()
            sql = "select * from tb_order where sendFlag={0} and (endTime<'{1}' or orderDate<'{2}') order by orderDate asc, endTime asc limit 20;".format(
                0, nowTime, todayDate)

            print sql
            cur.execute(sql)
            records = cur.fetchall()
            return records  # len(records)==0 if not exists
        except Exception as err:
            print "getNotSendOrderList with error=", err
            return []
        finally:
            conn.close()

    def confirmOrder(self, orderId):
        try:
            conn = sqlite3.connect(APP_DB_NAME)
            conn.execute("update tb_order set sendFlag = 1 where orderId=(?);", (orderId,))
            conn.commit()
        except Exception as err:
            print "confirmOrder with error=", err
        finally:
            conn.close()

    def getOrderItem(self, orderId):
        try:
            conn = sqlite3.connect(APP_DB_NAME)
            cur = conn.cursor()
            cur.execute("select * from tb_item where orderId=(?);", (orderId,))
            records = cur.fetchall()
            return records  # len(records)==0 if not exists
        except Exception as err:
            print "getOrderItem with error=", err
            return []
        finally:
            conn.close()

    def confirmErrorImg(self, pId, errTime):
        try:
            conn = sqlite3.connect(APP_DB_NAME)
            conn.execute("update tb_item_error set sendFlag = 1 where itemId=(?) and errorTime=(?);", (pId, errTime))
            conn.commit()
        except Exception as err:
            print "confirmErrorImg with error=", err
        finally:
            conn.close()

    def getItemErrorImgs(self, itemId):
        try:
            conn = sqlite3.connect(APP_DB_NAME)
            cur = conn.cursor()
            cur.execute("select * from tb_item_error where itemId=(?);", (itemId,))
            records = cur.fetchall()
            return records  # len(records)==0 if not exists
        except Exception as err:
            print "with error=", err
        finally:
            conn.close()

    def uploadItemErrorImgs(self, itemId):
        imgList = ""
        errList = ""
        errors = self.getItemErrorImgs(itemId)
        print errors
        for errInfo in errors:
            errImgPath = errInfo[5]
            errImgPath = unquote(errImgPath)
            errMsg = errInfo[3]
            errMsg = unquote(errMsg.encode('utf-8'))
            print "errImgPath", errImgPath
            if errInfo[6] == 0:
                sendRet = TOOLS().uploadOneErrorImg(errInfo[4])
                if sendRet[0]:
                    self.confirmErrorImg(errInfo[0], errInfo[1])
                    errImgPath = sendRet[1]
                else:
                    raise Exception("上传失败，稍后再试")
            if len(imgList) == 0:
                imgList = errImgPath
                errList = errMsg
            else:
                imgList += "," + errImgPath
                errList += "\r\n" + errMsg
        return imgList, errList


class TOOLS():
    def uploadLocalItem(self, userId, itemInfo, imgList, errList, anylyzeMsg):
        orderId = itemInfo[2]
        classId = itemInfo[3]
        print "classId", classId
        cumulativeTime = str(round(itemInfo[11] / 60.0, 2))
        completeTimes = str(1)
        journey = str(1)
        averageMarks = str(itemInfo[11])
        exerciseTimes = str(1)
        exerciseImage = imgList
        errorCount = str(itemInfo[10])
        print "============in uploadLocalItem============="
        print exerciseImage
        exerciseError = "没有错误"
        if len(errList) > 0:
            exerciseError = errList
        print exerciseError
        exerciseAnalyze = unquote(itemInfo[8].encode('utf-8'))  # anylyzeMsg
        # 上传失败抛异常
        callServerUrl = APP_BASE_URL + "/appactivity/userlessondata.html"
        dictUrl = {}
        dictUrl['orderId'] = orderId
        dictUrl['userId'] = userId
        dictUrl['practiceId'] = classId
        dictUrl['cumulativeTime'] = cumulativeTime
        dictUrl['completeTimes'] = completeTimes
        dictUrl['journey'] = journey
        dictUrl['averageMarks'] = averageMarks
        dictUrl['exerciseTimes'] = exerciseTimes
        dictUrl['exerciseImage'] = exerciseImage
        dictUrl['exerciseError'] = exerciseError
        dictUrl['exerciseAnalyze'] = exerciseAnalyze
        dictUrl['faultNo'] = errorCount  # len(imgList.split(','))
        '''		
        textmod = urlencode(dictUrl) #json.dumps(dictUrl)
        print(textmod)
        #输出内容:{"params": {"password": "zabbix", "user": "admin"}, "jsonrpc": "2.0", "method": "user.login", "auth": null, "id": 1}
        header_dict = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',"Content-Type": "application/json"}
        url='http://192.168.1.115:8080/tuobaba/appactivity/userlessondata.html'
        req = urllib2.Request(url=url,data=textmod,headers=header_dict)
        res = urllib2.urlopen(req)
        res = res.read()
        print(res)
        retMsg = json.loads(res)
        print "callAppServer ret[",retMsg,"]"
        print retMsg[u'msg'].encode('utf-8')
        return retMsg[u'success']
        #输出内容:{"jsonrpc":"2.0","result":"2c42e987811c90e0491f45904a67065d","id":1}
        '''
        data = urllib.urlencode(dictUrl)
        request = urllib2.Request(callServerUrl, data)
        response = urllib2.urlopen(request)
        filestr = response.read()
        print filestr
        retMsg = json.loads(filestr)
        print "callAppServer ret[", retMsg, "]"
        print retMsg[u'msg'].encode('utf-8')
        return retMsg[u'success']

    def doGetAnylyzemsg(self, orderId, pId):
        return "压线行驶一般都是占用对向车道行驶，或占用同向车道行驶。也就是本来车子只能在本车道一个车道内行驶，却占用了两个车道行驶，因此危害是十分巨大的"

    def uploadOneErrorImg(self, localPath):
        svrPath = ""
        return (True, svrPath)


def run():
    print "service run "
    print(str(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))))
    dbHandler = DB_APP()
    toolHandler = TOOLS()
    # 获取数据库中未上传的订单列表
    orders = dbHandler.getNotSendOrderList()
    print "订单数量", len(orders)
    for record in orders:
        orderId = record[0]
        userId = record[2]
        print orderId
        # 获取订单的所有练习
        items = dbHandler.getOrderItem(orderId)
        for item in items:
            itemId = item[0]
            # 将练习对应的未上传的错误列表截图都上传
            imgList, errList = dbHandler.uploadItemErrorImgs(itemId)
            anylyzeMsg = toolHandler.doGetAnylyzemsg(orderId, itemId)
            # 将本次练习的相关数据发送到后台
            retcode = toolHandler.uploadLocalItem(userId, item, imgList, errList, anylyzeMsg)
            print retcode
            if retcode == False:
                raise ValueError('后台返回报错')

        # 标记订单为已发送
        dbHandler.confirmOrder(orderId)


if __name__ == "__main__":
    while True:
        try:
            run()
        except Exception as err:
            print "run with error=", err
            exstr = traceback.format_exc()
            print exstr
        finally:
            time.sleep(60)
